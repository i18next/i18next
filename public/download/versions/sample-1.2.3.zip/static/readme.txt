best open index.html in firefox!

for other browsers you will have to deploy the sample on a server.